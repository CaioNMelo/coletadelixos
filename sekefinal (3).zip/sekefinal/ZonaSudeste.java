public class ZonaSudeste extends ZonaBase {
    public ZonaSudeste() {
        super("Zona Sudeste", Config.GERACAO_LIXO_ZONAS[4][0], Config.GERACAO_LIXO_ZONAS[4][1]);
    }
}

