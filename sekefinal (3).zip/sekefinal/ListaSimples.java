public class ListaSimples<T> implements Iterable<T> {
    private class No {
        T dado;
        No proximo;
        
        No(T dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }
    
    private No inicio;
    private int tamanho;
    
    public ListaSimples() {
        inicio = null;
        tamanho = 0;
    }
    
    public void adicionar(T elemento) {
        No novo = new No(elemento);
        if (inicio == null) {
            inicio = novo;
        } else {
            No atual = inicio;
            while (atual.proximo != null) {
                atual = atual.proximo;
            }
            atual.proximo = novo;
        }
        tamanho++;
    }
    
    public void remover(T elemento) {
        if (inicio == null) return;
        
        if (inicio.dado.equals(elemento)) {
            inicio = inicio.proximo;
            tamanho--;
            return;
        }
        
        No atual = inicio;
        while (atual.proximo != null) {
            if (atual.proximo.dado.equals(elemento)) {
                atual.proximo = atual.proximo.proximo;
                tamanho--;
                return;
            }
            atual = atual.proximo;
        }
    }
    
    public boolean contem(T elemento) {
        No atual = inicio;
        while (atual != null) {
            if (atual.dado.equals(elemento)) {
                return true;
            }
            atual = atual.proximo;
        }
        return false;
    }
    
    public int tamanho() {
        return tamanho;
    }
    
    public boolean estaVazia() {
        return inicio == null;
    }
    
    public void limpar() {
        inicio = null;
        tamanho = 0;
    }
    
    public T get(int indice) {
        if (indice < 0 || indice >= tamanho) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
        
        No atual = inicio;
        for (int i = 0; i < indice; i++) {
            atual = atual.proximo;
        }
        return atual.dado;
    }
    
    public void removerIf(java.util.function.Predicate<T> predicate) {
        if (inicio == null) return;
        
        while (inicio != null && predicate.test(inicio.dado)) {
            inicio = inicio.proximo;
            tamanho--;
        }
        
        if (inicio == null) return;
        
        No atual = inicio;
        while (atual.proximo != null) {
            if (predicate.test(atual.proximo.dado)) {
                atual.proximo = atual.proximo.proximo;
                tamanho--;
            } else {
                atual = atual.proximo;
            }
        }
    }

    @Override
    public java.util.Iterator<T> iterator() {
        return new Iterator();
    }

    private class Iterator implements java.util.Iterator<T> {
        private No atual = inicio;

        @Override
        public boolean hasNext() {
            return atual != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            T dado = atual.dado;
            atual = atual.proximo;
            return dado;
        }
    }
} 