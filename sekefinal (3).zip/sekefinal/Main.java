public class Main {
    public static void main(String[] args) {
        Simulador sim = new Simulador();
        sim.executar(60); // Simula 60 minutos 
    }
}
