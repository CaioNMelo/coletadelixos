import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Simulador {
    private ZonaBase[] zonas;
    private CaminhaoPequeno[] caminhoes;
    private EstacaoTransferencia[] estacoes;
    private ListaSimples<CaminhaoPequeno> caminhoesNaEstacao = new ListaSimples<>();

    public Simulador() {
        zonas = new ZonaBase[] {
            new ZonaSul(), new ZonaNorte(), new Centro(),
            new ZonaLeste(), new ZonaSudeste()
        };

        caminhoes = new CaminhaoPequeno[] {
            new CaminhaoPequeno(2000),
            new CaminhaoPequeno(4000),
            new CaminhaoPequeno(8000),
            new CaminhaoPequeno(10000)
        };

        estacoes = new EstacaoTransferencia[] {
            new EstacaoTransferencia(),
            new EstacaoTransferencia()
        };
    }

    public void executar(int minutos) {
        for (int i = 0; i < minutos; i++) {
            System.out.println("\n== Minuto " + (i + 1) + " ==");

            // Gera lixo em todas as zonas
            for (ZonaBase z : zonas) {
                int lixoGerado = z.gerarLixo();
                // Registra o lixo gerado em ambas as estações para estatísticas
                for (EstacaoTransferencia e : estacoes) {
                    e.registrarLixoGerado(z.getNome(), lixoGerado);
                }
            }

            // Atualiza viagens em andamento
            for (CaminhaoPequeno c : caminhoes) {
                c.atualizarViagem();
            }

            // Verifica caminhões cheios para enviar à estação
            for (CaminhaoPequeno c : caminhoes) {
                if (c.cheio() && !c.estaEmViagem() && !caminhoesNaEstacao.contem(c)) {
                    // Escolhe a estação com menor fila
                    EstacaoTransferencia estacaoEscolhida = estacoes[0];
                    if (estacoes[1].getTamanhoFila() < estacoes[0].getTamanhoFila()) {
                        estacaoEscolhida = estacoes[1];
                    }
                    
                    System.out.println("Enviando caminhão à estação " + estacaoEscolhida.getId() + 
                        " (carga: " + c.getCarga() + "kg)");
                    estacaoEscolhida.adicionarPequeno(c);
                    caminhoesNaEstacao.adicionar(c);
                }
            }

            // Inicia novas viagens para caminhões disponíveis
            for (CaminhaoPequeno c : caminhoes) {
                if (!c.cheio() && c.podeViajar() && !caminhoesNaEstacao.contem(c)) {
                    // Escolhe 2-3 zonas aleatórias para coletar
                    ListaSimples<ZonaBase> zonasParaColetar = new ListaSimples<>();
                    int numZonas = 2 + (int)(Math.random() * 2); // 2 ou 3 zonas
                    
                    // Embaralha as zonas
                    ListaSimples<ZonaBase> zonasDisponiveis = new ListaSimples<>();
                    for (ZonaBase z : zonas) {
                        zonasDisponiveis.adicionar(z);
                    }
                    
                    // Seleciona as primeiras N zonas
                    for (int j = 0; j < numZonas && !zonasDisponiveis.estaVazia(); j++) {
                        int indice = (int)(Math.random() * zonasDisponiveis.tamanho());
                        ZonaBase zona = zonasDisponiveis.get(indice);
                        zonasParaColetar.adicionar(zona);
                        zonasDisponiveis.remover(zona);
                    }
                    
                    c.iniciarColeta(zonasParaColetar, i);
                }
            }

            // Processa ambas as estações
            for (EstacaoTransferencia e : estacoes) {
                e.processar();
            }
            
            // Remove caminhões que foram processados da lista de caminhões na estação
            caminhoesNaEstacao.removerIf(c -> !c.cheio() && !c.estaEmViagem());
        }

        // Imprime estatísticas de ambas as estações
        for (EstacaoTransferencia e : estacoes) {
            e.imprimirEstatisticas();
        }
    }
}

