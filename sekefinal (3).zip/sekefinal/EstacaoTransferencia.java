import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EstacaoTransferencia {
    private FilaSimples<CaminhaoFila> filaPequenos = new FilaSimples<>();
    private ListaSimples<CaminhaoGrande> caminhoesGrandes = new ListaSimples<>();
    private int tempoEsperaGrande = 0;
    private int totalEspera = 0;
    private int totalAtendidos = 0;
    private int totalLixoProcessado = 0;
    private ListaSimples<CaminhaoPequeno> caminhoesAtendidos = new ListaSimples<>();
    private int idEstacao;
    private static int proximoId = 1;
    private Map<String, Integer> lixoPorZona = new HashMap<>();
    private Map<Integer, Integer> lixoPorCaminhaoPequeno = new HashMap<>();
    private Map<String, Integer> lixoGeradoPorZona = new HashMap<>();

    public EstacaoTransferencia() {
        this.idEstacao = proximoId++;
        // Inicializa com um caminhão grande
        caminhoesGrandes.adicionar(new CaminhaoGrande());
    }

    public int getId() {
        return idEstacao;
    }

    public int getTamanhoFila() {
        return filaPequenos.tamanho();
    }

    public void registrarLixoGerado(String zona, int quantidade) {
        lixoGeradoPorZona.merge(zona, quantidade, Integer::sum);
    }

    public void adicionarPequeno(CaminhaoPequeno c) {
        filaPequenos.enfileirar(new CaminhaoFila(c));
        lixoPorCaminhaoPequeno.put(c.hashCode(), c.getTotalColetado());
    }

    public void processar() {
        // Processa todos os caminhões na fila
        while (!filaPequenos.estaVazia()) {
            CaminhaoFila cf = filaPequenos.desenfileirar();
            cf.incrementarEspera();
            
            // Verifica se precisa adicionar novo caminhão grande
            if (cf.getTempoEspera() >= Config.ESPERA_MAXIMA_PEQUENO) {
                caminhoesGrandes.adicionar(new CaminhaoGrande());
                System.out.println("Estação " + idEstacao + ": Novo caminhão grande adicionado devido ao tempo de espera!");
            }

            // Atualiza estatísticas de lixo por zona
            Map<String, Integer> lixoCaminhao = cf.getCaminhao().getLixoPorZona();
            for (Map.Entry<String, Integer> entry : lixoCaminhao.entrySet()) {
                lixoPorZona.merge(entry.getKey(), entry.getValue(), Integer::sum);
            }

            int kg = cf.getCaminhao().descarregar();
            totalLixoProcessado += kg;
            caminhoesAtendidos.adicionar(cf.getCaminhao());
            
            // Tenta carregar em um caminhão grande disponível
            boolean carregado = false;
            for (CaminhaoGrande cg : caminhoesGrandes) {
                if (!cg.cheio()) {
                    cg.carregar(kg);
                    carregado = true;
                    break;
                }
            }

            totalEspera += cf.getTempoEspera();
            totalAtendidos++;
        }

        // Processa caminhões grandes
        for (CaminhaoGrande cg : caminhoesGrandes) {
            if (cg.cheio() || cg.getTempoEspera() >= Config.TOLERANCIA_ESPERA_GRANDE) {
                cg.transportar();
            }
        }
    }

    public void imprimirEstatisticas() {
        System.out.println("\n=== Estatísticas da Estação " + idEstacao + " ===");
        
        System.out.println("\nGeração de Lixo por Zona:");
        for (Map.Entry<String, Integer> entry : lixoGeradoPorZona.entrySet()) {
            System.out.printf("%s: %d kg gerados\n", entry.getKey(), entry.getValue());
        }

        System.out.println("\nColeta de Lixo por Zona:");
        for (Map.Entry<String, Integer> entry : lixoPorZona.entrySet()) {
            int gerado = lixoGeradoPorZona.getOrDefault(entry.getKey(), 0);
            int coletado = entry.getValue();
            double percentual = gerado > 0 ? (coletado * 100.0 / gerado) : 0;
            System.out.printf("%s: %d kg coletados (%.1f%% do total gerado)\n", 
                entry.getKey(), coletado, percentual);
        }

        if (totalAtendidos > 0) {
            System.out.println("\nCaminhões Grandes:");
            int totalLixoGrande = 0;
            for (CaminhaoGrande cg : caminhoesGrandes) {
                int transportado = cg.getTotalTransportado();
                totalLixoGrande += transportado;
                System.out.printf("Caminhão Grande: %d kg transportados\n", transportado);
            }

            System.out.println("\nCaminhões Pequenos:");
            int totalLixoPequeno = 0;
            for (CaminhaoPequeno cp : caminhoesAtendidos) {
                int coletado = cp.getTotalColetado();
                totalLixoPequeno += coletado;
                System.out.printf("Caminhão Pequeno (Capacidade: %d kg): %d kg coletados\n",
                    cp.getCapacidade(), coletado);
            }

            System.out.println("\nTotais:");
            System.out.printf("Total de lixo processado: %d kg\n", totalLixoProcessado);
            System.out.printf("Total de lixo transportado: %d kg\n", totalLixoGrande);
            System.out.printf("Caminhões pequenos atendidos: %d\n", totalAtendidos);
            System.out.printf("Tempo médio de espera: %.1f minutos\n", 
                (double)totalEspera / totalAtendidos);
        } else {
            System.out.println("\nNenhum caminhão foi atendido nesta estação.");
        }
    }
}
