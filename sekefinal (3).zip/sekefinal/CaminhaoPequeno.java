import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class CaminhaoPequeno {
    private int capacidade;
    private int carga = 0;
    private int viagens = 0;
    private int totalColetado = 0;
    private Map<String, Integer> lixoPorZona = new HashMap<>();
    private int tempoViagemAtual = 0;
    private boolean emViagem = false;
    private ZonaBase zonaAtual = null;
    private List<ZonaBase> zonasParaColetar = new ArrayList<>();
    private int minutoAtual = 0;

    public CaminhaoPequeno(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public boolean podeViajar() {
        boolean pode = viagens < Config.MAX_VIAGENS_PEQ && !emViagem;
        if (!pode) {
            System.out.println("Caminhão não pode viajar: viagens=" + viagens + 
                ", emViagem=" + emViagem);
        }
        return pode;
    }

    private boolean estaEmHorarioPico(int minutoAtual) {
        for (int[] horario : Config.HORARIOS_PICO) {
            if (minutoAtual >= horario[0] && minutoAtual <= horario[1]) {
                return true;
            }
        }
        return false;
    }

    private int calcularTempoViagem(ZonaBase zona, int minutoAtual) {
        int indiceZona = -1;
        if (zona instanceof ZonaSul) indiceZona = 0;
        else if (zona instanceof ZonaNorte) indiceZona = 1;
        else if (zona instanceof Centro) indiceZona = 2;
        else if (zona instanceof ZonaLeste) indiceZona = 3;
        else if (zona instanceof ZonaSudeste) indiceZona = 4;

        if (indiceZona == -1) return 0;

        int[][] tempos = estaEmHorarioPico(minutoAtual) ? 
            Config.TEMPO_VIAGEM_PICO : Config.TEMPO_VIAGEM_FORA_PICO;

        int min = tempos[indiceZona][0];
        int max = tempos[indiceZona][1];
        return (int)(Math.random() * (max - min + 1)) + min;
    }

    public void iniciarColeta(ListaSimples<ZonaBase> zonas, int minutoAtual) {
        if (!podeViajar() || zonas.estaVazia()) {
            System.out.println("Não foi possível iniciar coleta: podeViajar=" + podeViajar() + 
                ", zonas vazias=" + zonas.estaVazia());
            return;
        }
        this.minutoAtual = minutoAtual;
        this.zonasParaColetar = new ArrayList<>();
        for (ZonaBase z : zonas) {
            this.zonasParaColetar.add(z);
        }
        zonaAtual = this.zonasParaColetar.remove(0);
        tempoViagemAtual = calcularTempoViagem(zonaAtual, minutoAtual);
        emViagem = true;
        System.out.println("Caminhão iniciou viagem para " + zonaAtual.getNome() + 
            " (tempo estimado: " + tempoViagemAtual + " minutos)");
    }

    public void atualizarViagem() {
        if (emViagem) {
            tempoViagemAtual--;
            if (tempoViagemAtual <= 0) {
                if (zonaAtual != null) {
                    coletar(zonaAtual);
                    zonaAtual = null;
                }
                
                if (!zonasParaColetar.isEmpty() && !cheio()) {
                    zonaAtual = zonasParaColetar.remove(0);
                    tempoViagemAtual = calcularTempoViagem(zonaAtual, minutoAtual);
                    System.out.println("Caminhão indo para próxima zona: " + zonaAtual.getNome());
                } else {
                    emViagem = false;
                    if (cheio()) {
                        System.out.println("Caminhão está cheio! Carga: " + carga + "/" + capacidade);
                    } else {
                        System.out.println("Caminhão terminou a rota. Carga atual: " + carga + "/" + capacidade);
                    }
                }
            }
        }
    }

    public void coletar(ZonaBase z) {
        int coletado = z.coletarLixo(capacidade - carga);
        carga += coletado;
        totalColetado += coletado;
        viagens++;
        lixoPorZona.merge(z.getNome(), coletado, Integer::sum);
        System.out.println("Coletado " + coletado + "kg de " + z.getNome() + 
            " (carga atual: " + carga + "/" + capacidade + "kg)");
    }

    public boolean cheio() {
        return carga >= capacidade;
    }

    public int descarregar() {
        int c = carga;
        carga = 0;
        return c;
    }

    public Map<String, Integer> getLixoPorZona() {
        return lixoPorZona;
    }

    public int getTotalColetado() {
        return totalColetado;
    }

    public boolean estaEmViagem() {
        return emViagem;
    }

    public int getCarga() {
        return carga;
    }
}
