public class ZonaSul extends ZonaBase {
    public ZonaSul() {
        super("Zona Sul", Config.GERACAO_LIXO_ZONAS[0][0], Config.GERACAO_LIXO_ZONAS[0][1]);
    }
}

