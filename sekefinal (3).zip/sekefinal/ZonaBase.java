public abstract class ZonaBase {
    protected String nome;
    protected int lixoAcumulado = 0;
    protected int geracaoMin, geracaoMax;

    public ZonaBase(String nome, int min, int max) {
        this.nome = nome;
        this.geracaoMin = min;
        this.geracaoMax = max;
    }

    public int gerarLixo() {
        int gerado = (int)(Math.random() * (geracaoMax - geracaoMin + 1)) + geracaoMin;
        lixoAcumulado += gerado;
        System.out.println(nome + " gerou " + gerado + "kg (acumulado: " + lixoAcumulado + ")");
        return gerado;
    }

    public int coletarLixo(int capacidade) {
        int coletado = Math.min(capacidade, lixoAcumulado);
        lixoAcumulado -= coletado;
        return coletado;
    }

    public String getNome() { return nome; }
    public int getLixoAcumulado() { return lixoAcumulado; }
}

