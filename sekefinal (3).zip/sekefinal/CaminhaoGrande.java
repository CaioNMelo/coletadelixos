public class CaminhaoGrande {
    private int carga = 0;
    private int totalTransportado = 0;
    private int tempoEspera = 0;

    public void carregar(int kg) {
        carga += kg;
        tempoEspera = 0; // Reseta o tempo de espera quando carrega
    }

    public boolean cheio() {
        return carga >= Config.CAPACIDADE_GRANDE;
    }

    public void transportar() {
        System.out.println("Caminhão grande transportou " + carga + "kg ao aterro.");
        totalTransportado += carga;
        carga = 0;
        tempoEspera = 0;
    }

    public void incrementarEspera() {
        tempoEspera++;
    }

    public int getTempoEspera() {
        return tempoEspera;
    }

    public int getCarga() {
        return carga;
    }

    public int getTotalTransportado() {
        return totalTransportado;
    }
}
