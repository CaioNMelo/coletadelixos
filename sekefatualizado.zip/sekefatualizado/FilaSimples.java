public class FilaSimples<T> {
    private class No {
        T dado;
        No proximo;
        
        No(T dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }
    
    private No inicio;
    private No fim;
    private int tamanho;
    
    public FilaSimples() {
        inicio = null;
        fim = null;
        tamanho = 0;
    }
    
    public void enfileirar(T elemento) {
        No novo = new No(elemento);
        if (estaVazia()) {
            inicio = novo;
        } else {
            fim.proximo = novo;
        }
        fim = novo;
        tamanho++;
    }
    
    public T desenfileirar() {
        if (estaVazia()) {
            throw new IllegalStateException("Fila vazia");
        }
        T elemento = inicio.dado;
        inicio = inicio.proximo;
        if (inicio == null) {
            fim = null;
        }
        tamanho--;
        return elemento;
    }
    
    public boolean estaVazia() {
        return inicio == null;
    }
    
    public int tamanho() {
        return tamanho;
    }
    
    public T primeiro() {
        if (estaVazia()) {
            throw new IllegalStateException("Fila vazia");
        }
        return inicio.dado;
    }
}

