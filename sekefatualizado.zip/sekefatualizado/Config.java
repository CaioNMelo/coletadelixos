public class Config {
    public static final int[] CAPACIDADES_PEQUENOS = {2000, 4000, 8000, 10000}; // kg
    public static final int CAPACIDADE_GRANDE = 20000;

    public static final int MAX_VIAGENS_PEQ = 10;

    // Tempos de viagem em minutos (mínimo, máximo)
    public static final int[][] TEMPO_VIAGEM_PICO = {
        {5, 10},  // Sul
        {6, 12},  // Norte
        {3, 8},   // Centro
        {5, 10},  // Leste
        {4, 9}    // Sudeste
    };

    public static final int[][] TEMPO_VIAGEM_FORA_PICO = {
        {3, 6},   // Sul
        {4, 8},   // Norte
        {2, 5},   // Centro
        {3, 7},   // Leste
        {3, 6}    // Sudeste
    };

    public static final int TEMPO_PICO_MIN = 2;
    public static final int TEMPO_PICO_MAX = 5;
    public static final int TEMPO_FORA_PICO_MIN = 1;
    public static final int TEMPO_FORA_PICO_MAX = 3;

    public static final int TOLERANCIA_ESPERA_GRANDE = 5;
    public static final int ESPERA_MAXIMA_PEQUENO = 4;

    // Geração de lixo por zona (em kg por minuto)
    public static final int[][] GERACAO_LIXO_ZONAS = {
        {1500, 2500}, // Sul
        {1300, 2300}, // Norte
        {1200, 2200}, // Centro
        {1400, 2400}, // Leste
        {1600, 2600}  // Sudeste
    };

    // Horários de pico (em minutos desde o início do dia)
    public static final int[][] HORARIOS_PICO = {
        {480, 720},   // Manhã: 8:00 - 12:00
        {1020, 1260}  // Tarde: 17:00 - 21:00
    };
}

