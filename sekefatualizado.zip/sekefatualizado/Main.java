public class Main {
    public static void main(String[] args) {
        System.out.println("=== Simulador de Coleta de Lixo para Teresina ===");
        System.out.println("Iniciando simulação de 24 horas...");
        
        Simulador simulador = new Simulador();
        simulador.executar(24 * 60);
        
        System.out.println("\nSimulação concluída!");
    }
}
