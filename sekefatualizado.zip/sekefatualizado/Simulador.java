import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Simulador {
    private ZonaBase[] zonas;
    private CaminhaoPequeno[] caminhoes;
    private EstacaoTransferencia[] estacoes;
    private ListaSimples<CaminhaoPequeno> caminhoesNaEstacao = new ListaSimples<>();
    private EstatisticasSimulacao estatisticas;
    private int tempoSimulacao;
    private boolean horarioPico;

    public Simulador() {
        zonas = new ZonaBase[] {
            new ZonaSul(), new ZonaNorte(), new Centro(),
            new ZonaLeste(), new ZonaSudeste()
        };

        caminhoes = new CaminhaoPequeno[] {
            new CaminhaoPequeno(2000),
            new CaminhaoPequeno(4000),
            new CaminhaoPequeno(8000),
            new CaminhaoPequeno(10000)
        };

        estacoes = new EstacaoTransferencia[] {
            new EstacaoTransferencia(),
            new EstacaoTransferencia()
        };
        
        estatisticas = new EstatisticasSimulacao();
        tempoSimulacao = 0;
        horarioPico = false;
    }

    private void atualizarHorarioPico() {
        int hora = (tempoSimulacao / 60) % 24;
        horarioPico = (hora >= 7 && hora < 9) || (hora >= 17 && hora < 19);
    }

    public void executar(int minutos) {
        for (int i = 0; i < minutos; i++) {
            tempoSimulacao++;
            atualizarHorarioPico();
            
            System.out.println("\n== Minuto " + tempoSimulacao + " ==");
            System.out.println("Horário: " + String.format("%02d:%02d", (tempoSimulacao/60)%24, tempoSimulacao%60));
            System.out.println("Período: " + (horarioPico ? "Pico" : "Fora de Pico"));

            for (ZonaBase z : zonas) {
                int lixoGerado = z.gerarLixo();
                estatisticas.registrarLixoGerado(lixoGerado);
                for (EstacaoTransferencia e : estacoes) {
                    e.registrarLixoGerado(z.getNome(), lixoGerado);
                }
            }

            for (CaminhaoPequeno c : caminhoes) {
                if (c.atualizarViagem()) {
                    estatisticas.registrarViagemPequeno();
                }
            }

            for (CaminhaoPequeno c : caminhoes) {
                if (c.cheio() && !c.estaEmViagem() && !caminhoesNaEstacao.contem(c)) {
                    EstacaoTransferencia estacaoEscolhida = estacoes[0];
                    if (estacoes[1].getTamanhoFila() < estacoes[0].getTamanhoFila()) {
                        estacaoEscolhida = estacoes[1];
                    }
                    
                    System.out.println("Enviando caminhão à estação " + estacaoEscolhida.getId() + 
                        " (carga: " + c.getCarga() + "kg)");
                    estacaoEscolhida.adicionarPequeno(c);
                    caminhoesNaEstacao.adicionar(c);
                }
            }

            for (CaminhaoPequeno c : caminhoes) {
                if (!c.cheio() && c.podeViajar() && !caminhoesNaEstacao.contem(c)) {
                    ListaSimples<ZonaBase> zonasParaColetar = new ListaSimples<>();
                    int numZonas = 2 + (int)(Math.random() * 2);
                    
                    ListaSimples<ZonaBase> zonasDisponiveis = new ListaSimples<>();
                    for (ZonaBase z : zonas) {
                        zonasDisponiveis.adicionar(z);
                    }
                    
                    for (int j = 0; j < numZonas && !zonasDisponiveis.estaVazia(); j++) {
                        int indice = (int)(Math.random() * zonasDisponiveis.tamanho());
                        ZonaBase zona = zonasDisponiveis.get(indice);
                        zonasParaColetar.adicionar(zona);
                        zonasDisponiveis.remover(zona);
                    }
                    
                    c.iniciarColeta(zonasParaColetar, tempoSimulacao, horarioPico);
                }
            }

            for (EstacaoTransferencia e : estacoes) {
                e.processar(estatisticas);
            }
            
            caminhoesNaEstacao.removerIf(c -> !c.cheio() && !c.estaEmViagem());
        }

        estatisticas.imprimirEstatisticas();
        for (EstacaoTransferencia e : estacoes) {
            e.imprimirEstatisticas();
        }
    }
}

