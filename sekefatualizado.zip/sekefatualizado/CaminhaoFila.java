public class CaminhaoFila {
    private CaminhaoPequeno caminhao;
    private int tempoEspera = 0;

    public CaminhaoFila(CaminhaoPequeno c) { this.caminhao = c; }

    public void incrementarEspera() { tempoEspera++; }
    public int getTempoEspera() { return tempoEspera; }
    public CaminhaoPequeno getCaminhao() { return caminhao; }
}

