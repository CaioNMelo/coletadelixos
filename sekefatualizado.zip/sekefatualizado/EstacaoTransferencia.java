import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EstacaoTransferencia {
    private static int contador = 0;
    private int id;
    private FilaSimples<CaminhaoPequeno> filaPequenos;
    private ListaSimples<CaminhaoGrande> caminhoesGrandes;
    private Map<String, Integer> lixoPorZona;
    private int tempoMaximoEspera;
    private int toleranciaGrande;
    private int totalLixoProcessado;
    private int totalCaminhoesAtendidos;
    private int tempoTotalEspera;

    public EstacaoTransferencia() {
        this.id = ++contador;
        this.filaPequenos = new FilaSimples<>();
        this.caminhoesGrandes = new ListaSimples<>();
        this.lixoPorZona = new HashMap<>();
        this.tempoMaximoEspera = 120;
        this.toleranciaGrande = 30;
        this.totalLixoProcessado = 0;
        this.totalCaminhoesAtendidos = 0;
        this.tempoTotalEspera = 0;
        adicionarCaminhaoGrande();
    }

    public void adicionarPequeno(CaminhaoPequeno caminhao) {
        filaPequenos.enfileirar(caminhao);
    }

    private void adicionarCaminhaoGrande() {
        caminhoesGrandes.adicionar(new CaminhaoGrande());
    }

    public void processar(EstatisticasSimulacao estatisticas) {
        for (CaminhaoGrande grande : caminhoesGrandes) {
            if (grande.estaCheio()) {
                grande.descarregar();
                estatisticas.registrarViagemGrande();
            } else if (grande.getTempoEspera() >= toleranciaGrande && grande.getCarga() > 0) {
                grande.descarregar();
                estatisticas.registrarViagemGrande();
            }
        }

        while (!filaPequenos.estaVazia()) {
            CaminhaoPequeno pequeno = filaPequenos.primeiro();
            boolean precisaNovoCaminhao = true;
            for (CaminhaoGrande grande : caminhoesGrandes) {
                if (!grande.estaCheio()) {
                    precisaNovoCaminhao = false;
                    break;
                }
            }
            if (precisaNovoCaminhao) {
                adicionarCaminhaoGrande();
                estatisticas.registrarCaminhaoGrande();
            }
            boolean descarregou = false;
            for (CaminhaoGrande grande : caminhoesGrandes) {
                if (!grande.estaCheio()) {
                    int carga = pequeno.getCarga();
                    if (grande.adicionarCarga(carga)) {
                        pequeno.descarregar();
                        totalLixoProcessado += carga;
                        totalCaminhoesAtendidos++;
                        estatisticas.registrarLixoColetado(carga);
                        descarregou = true;
                        break;
                    }
                }
            }
            if (descarregou) {
                filaPequenos.desenfileirar();
            } else {
                tempoTotalEspera++;
                if (tempoTotalEspera >= tempoMaximoEspera) {
                    adicionarCaminhaoGrande();
                    estatisticas.registrarCaminhaoGrande();
                }
                break;
            }
        }
    }

    public void registrarLixoGerado(String zona, int quantidade) {
        lixoPorZona.merge(zona, quantidade, Integer::sum);
    }

    public int getTamanhoFila() {
        return filaPequenos.tamanho();
    }

    public int getId() {
        return id;
    }

    public void imprimirEstatisticas() {
        System.out.println("\n=== Estatísticas da Estação " + id + " ===");
        System.out.println("Total de Lixo Processado: " + totalLixoProcessado + " kg");
        System.out.println("Total de Caminhões Atendidos: " + totalCaminhoesAtendidos);
        System.out.println("Tempo Médio de Espera: " + 
            (totalCaminhoesAtendidos > 0 ? tempoTotalEspera / totalCaminhoesAtendidos : 0) + 
            " minutos");
        System.out.println("Caminhões Grandes em Operação: " + caminhoesGrandes.tamanho());
        System.out.println("Lixo por Zona:");
        for (Map.Entry<String, Integer> entry : lixoPorZona.entrySet()) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " kg");
        }
    }
}
