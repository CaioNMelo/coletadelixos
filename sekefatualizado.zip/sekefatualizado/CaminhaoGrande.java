public class CaminhaoGrande {
    private static final int CAPACIDADE = 20000; // 20 toneladas
    private int carga;
    private int tempoEspera;
    private int totalTransportado;

    public CaminhaoGrande() {
        this.carga = 0;
        this.tempoEspera = 0;
        this.totalTransportado = 0;
    }

    public boolean adicionarCarga(int quantidade) {
        if (carga + quantidade <= CAPACIDADE) {
            carga += quantidade;
            tempoEspera = 0;
            return true;
        }
        return false;
    }

    public void descarregar() {
        totalTransportado += carga;
        carga = 0;
        tempoEspera = 0;
    }

    public boolean estaCheio() {
        return carga >= CAPACIDADE;
    }

    public int getCarga() {
        return carga;
    }

    public int getTempoEspera() {
        return tempoEspera;
    }

    public void incrementarTempoEspera() {
        tempoEspera++;
    }

    public int getTotalTransportado() {
        return totalTransportado;
    }
}
