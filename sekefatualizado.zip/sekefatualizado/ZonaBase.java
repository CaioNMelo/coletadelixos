public abstract class ZonaBase {
    protected String nome;
    protected int lixoDisponivel;
    protected int lixoGerado;
    protected int minLixoDiario;
    protected int maxLixoDiario;

    public ZonaBase(String nome, int minLixoDiario, int maxLixoDiario) {
        this.nome = nome;
        this.minLixoDiario = minLixoDiario;
        this.maxLixoDiario = maxLixoDiario;
        this.lixoDisponivel = 0;
        this.lixoGerado = 0;
    }

    public int gerarLixo() {
        int lixo = minLixoDiario + (int)(Math.random() * (maxLixoDiario - minLixoDiario + 1));
        lixoDisponivel += lixo;
        lixoGerado += lixo;
        return lixo;
    }

    public int getLixoDisponivel() {
        return lixoDisponivel;
    }

    public void removerLixo(int quantidade) {
        if (quantidade > lixoDisponivel) {
            quantidade = lixoDisponivel;
        }
        lixoDisponivel -= quantidade;
    }

    public String getNome() {
        return nome;
    }

    public int getLixoGerado() {
        return lixoGerado;
    }
}

