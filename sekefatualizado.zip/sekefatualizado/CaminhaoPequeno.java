import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class CaminhaoPequeno {
    private int capacidade;
    private int carga;
    private boolean emViagem;
    private int tempoRestante;
    private ListaSimples<ZonaBase> zonasColeta;
    private int maxViagens;
    private int viagensRealizadas;
    private int ultimaViagem;
    private int totalColetado = 0;
    private Map<String, Integer> lixoPorZona = new HashMap<>();
    private int tempoViagemAtual = 0;
    private ZonaBase zonaAtual = null;
    private List<ZonaBase> zonasParaColetar = new ArrayList<>();
    private int minutoAtual = 0;

    public CaminhaoPequeno(int capacidade) {
        this.capacidade = capacidade;
        this.carga = 0;
        this.emViagem = false;
        this.tempoRestante = 0;
        this.zonasColeta = new ListaSimples<>();
        this.maxViagens = 8;
        this.viagensRealizadas = 0;
        this.ultimaViagem = 0;
    }

    public boolean atualizarViagem() {
        if (emViagem && tempoRestante > 0) {
            tempoRestante--;
            if (tempoRestante == 0) {
                emViagem = false;
                coletarLixo();
                return true;
            }
        }
        return false;
    }

    private void coletarLixo() {
        for (ZonaBase zona : zonasColeta) {
            int lixoDisponivel = zona.getLixoDisponivel();
            int espacoDisponivel = capacidade - carga;
            int lixoColetado = Math.min(lixoDisponivel, espacoDisponivel);
            
            if (lixoColetado > 0) {
                zona.removerLixo(lixoColetado);
                carga += lixoColetado;
            }
        }
        zonasColeta.limpar();
    }

    public void iniciarColeta(ListaSimples<ZonaBase> zonas, int tempoAtual, boolean horarioPico) {
        if (podeViajar() && !emViagem) {
            zonasColeta = zonas;
            emViagem = true;
            int tempoBase = 30 + (int)(Math.random() * 31);
            if (horarioPico) {
                tempoBase = (int)(tempoBase * 1.5);
            }
            tempoRestante = tempoBase;
            ultimaViagem = tempoAtual;
            viagensRealizadas++;
        }
    }

    public boolean podeViajar() {
        return viagensRealizadas < maxViagens;
    }

    public boolean cheio() {
        return carga >= capacidade;
    }

    public boolean estaEmViagem() {
        return emViagem;
    }

    public int getCarga() {
        return carga;
    }

    public void descarregar() {
        carga = 0;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public int getTotalColetado() {
        return totalColetado;
    }

    public Map<String, Integer> getLixoPorZona() {
        return lixoPorZona;
    }
}
