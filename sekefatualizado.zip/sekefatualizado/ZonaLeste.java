public class ZonaLeste extends ZonaBase {
    public ZonaLeste()
    {
        super("Zona Leste", Config.GERACAO_LIXO_ZONAS[3][0], Config.GERACAO_LIXO_ZONAS[3][1]);
    }
}

