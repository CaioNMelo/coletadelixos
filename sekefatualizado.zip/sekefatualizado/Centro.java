public class Centro extends ZonaBase {
    public Centro() {
        super("Centro", Config.GERACAO_LIXO_ZONAS[2][0], Config.GERACAO_LIXO_ZONAS[2][1]);
    }
}

