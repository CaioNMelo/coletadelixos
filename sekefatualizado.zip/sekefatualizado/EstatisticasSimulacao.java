public class EstatisticasSimulacao {
    private int totalLixoGerado;
    private int totalLixoColetado;
    private int totalCaminhoesGrandesUtilizados;
    private int tempoMedioEspera;
    private int maxTempoEspera;
    private int totalViagensPequenos;
    private int totalViagensGrandes;
    
    public void registrarLixoGerado(int quantidade) {
        totalLixoGerado += quantidade;
    }
    
    public void registrarLixoColetado(int quantidade) {
        totalLixoColetado += quantidade;
    }
    
    public void registrarCaminhaoGrande() {
        totalCaminhoesGrandesUtilizados++;
    }
    
    public void registrarTempoEspera(int tempo) {
        tempoMedioEspera = (tempoMedioEspera + tempo) / 2;
        if (tempo > maxTempoEspera) {
            maxTempoEspera = tempo;
        }
    }
    
    public void registrarViagemPequeno() {
        totalViagensPequenos++;
    }
    
    public void registrarViagemGrande() {
        totalViagensGrandes++;
    }
    
    public void imprimirEstatisticas() {
        System.out.println("\n=== Estatísticas da Simulação ===");
        System.out.println("Total de Lixo Gerado: " + totalLixoGerado + " kg");
        System.out.println("Total de Lixo Coletado: " + totalLixoColetado + " kg");
        System.out.println("Total de Caminhões Grandes Utilizados: " + totalCaminhoesGrandesUtilizados);
        System.out.println("Tempo Médio de Espera: " + tempoMedioEspera + " minutos");
        System.out.println("Tempo Máximo de Espera: " + maxTempoEspera + " minutos");
        System.out.println("Total de Viagens Caminhões Pequenos: " + totalViagensPequenos);
        System.out.println("Total de Viagens Caminhões Grandes: " + totalViagensGrandes);
        System.out.println("Eficiência de Coleta: " + 
            String.format("%.2f", (double)totalLixoColetado/totalLixoGerado * 100) + "%");
    }
} 