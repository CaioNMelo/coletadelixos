public class ZonaNorte extends ZonaBase {
    public ZonaNorte()
    {
        super("Zona Norte", Config.GERACAO_LIXO_ZONAS[1][0], Config.GERACAO_LIXO_ZONAS[1][1]);
    }
}

